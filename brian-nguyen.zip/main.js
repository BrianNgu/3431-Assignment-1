
var canvas;
var gl;

var program;

var near = 1;
var far = 100;

// Size of the viewport in viewing coordinates
var left = -6.0;
var right = 6.0;
var ytop = 6.0;
var bottom = -6.0;


var lightPosition2 = vec4(100.0, 100.0, 100.0, 1.0);
var lightPosition = vec4(0.0, 0.0, 100.0, 1.0);

var lightAmbient = vec4(0.2, 0.2, 0.2, 1.0);
var lightDiffuse = vec4(1.0, 1.0, 1.0, 1.0);
var lightSpecular = vec4(1.0, 1.0, 1.0, 1.0);

var materialAmbient = vec4(1.0, 0.0, 1.0, 1.0);
var materialDiffuse = vec4(1.0, 0.8, 0.0, 1.0);
var materialSpecular = vec4(0.4, 0.4, 0.4, 1.0);
var materialShininess = 30.0;

var ambientColor, diffuseColor, specularColor;

var modelMatrix, viewMatrix, modelViewMatrix, projectionMatrix, normalMatrix;
var modelViewMatrixLoc, projectionMatrixLoc, normalMatrixLoc;
var eye;
var at = vec3(0.0, 0.0, 0.0);
var up = vec3(0.0, 1.0, 0.0);

var RX = 0;
var RY = 0;
var RZ = 0;

var MS = []; // The modeling matrix stack
var TIME = 0.0; // Realtime
var prevTime = 0.0;
var resetTimerFlag = true;
var animFlag = false;
var controller;

var lastLaunch = 0;



function setColor(c) {
    ambientProduct = mult(lightAmbient, c);
    diffuseProduct = mult(lightDiffuse, c);
    specularProduct = mult(lightSpecular, materialSpecular);

    gl.uniform4fv(gl.getUniformLocation(program,
        "ambientProduct"), flatten(ambientProduct));
    gl.uniform4fv(gl.getUniformLocation(program,
        "diffuseProduct"), flatten(diffuseProduct));
    gl.uniform4fv(gl.getUniformLocation(program,
        "specularProduct"), flatten(specularProduct));
    gl.uniform4fv(gl.getUniformLocation(program,
        "lightPosition"), flatten(lightPosition));
    gl.uniform1f(gl.getUniformLocation(program,
        "shininess"), materialShininess);
}

window.onload = function init() {

    canvas = document.getElementById("gl-canvas");

    gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) { alert("WebGL isn't available"); }

    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(0.5, 0.5, 1.0, 1.0);

    gl.enable(gl.DEPTH_TEST);

    //
    //  Load shaders and initialize attribute buffers
    //
    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);


    setColor(materialDiffuse);

    Cube.init(program);
    Cylinder.init(9, program);
    Cone.init(9, program);
    Sphere.init(36, program);


    modelViewMatrixLoc = gl.getUniformLocation(program, "modelViewMatrix");
    normalMatrixLoc = gl.getUniformLocation(program, "normalMatrix");
    projectionMatrixLoc = gl.getUniformLocation(program, "projectionMatrix");


    gl.uniform4fv(gl.getUniformLocation(program,
        "ambientProduct"), flatten(ambientProduct));
    gl.uniform4fv(gl.getUniformLocation(program,
        "diffuseProduct"), flatten(diffuseProduct));
    gl.uniform4fv(gl.getUniformLocation(program,
        "specularProduct"), flatten(specularProduct));
    gl.uniform4fv(gl.getUniformLocation(program,
        "lightPosition"), flatten(lightPosition));
    gl.uniform1f(gl.getUniformLocation(program,
        "shininess"), materialShininess);


    document.getElementById("sliderXi").oninput = function () {
        RX = this.value;
        window.requestAnimFrame(render);
    }


    document.getElementById("sliderYi").oninput = function () {
        RY = this.value;
        window.requestAnimFrame(render);
    };
    document.getElementById("sliderZi").oninput = function () {
        RZ = this.value;
        window.requestAnimFrame(render);
    };

    document.getElementById("animToggleButton").onclick = function () {
        if (animFlag) {
            animFlag = false;
        }
        else {
            animFlag = true;
            resetTimerFlag = true;
            window.requestAnimFrame(render);
        }
        console.log(animFlag);

        controller = new CameraController(canvas);
        controller.onchange = function (xRot, yRot) {
            RX = xRot;
            RY = yRot;
            window.requestAnimFrame(render);
        };
    };

    render();
}

// Sets the modelview and normal matrix in the shaders
function setMV() {
    modelViewMatrix = mult(viewMatrix, modelMatrix);
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    normalMatrix = inverseTranspose(modelViewMatrix);
    gl.uniformMatrix4fv(normalMatrixLoc, false, flatten(normalMatrix));
}

// Sets the projection, modelview and normal matrix in the shaders
function setAllMatrices() {
    gl.uniformMatrix4fv(projectionMatrixLoc, false, flatten(projectionMatrix));
    setMV();

}

// Draws a 2x2x2 cube center at the origin
// Sets the modelview matrix and the normal matrix of the global program
function drawCube() {
    setMV();
    Cube.draw();
}

// Draws a sphere centered at the origin of radius 1.0.
// Sets the modelview matrix and the normal matrix of the global program
function drawSphere() {
    setMV();
    Sphere.draw();
}
// Draws a cylinder along z of height 1 centered at the origin
// and radius 0.5.
// Sets the modelview matrix and the normal matrix of the global program
function drawCylinder() {
    setMV();
    Cylinder.draw();
}

// Draws a cone along z of height 1 centered at the origin
// and base radius 1.0.
// Sets the modelview matrix and the normal matrix of the global program
function drawCone() {
    setMV();
    Cone.draw();
}





// Post multiples the modelview matrix with a translation matrix
// and replaces the modeling matrix with the result
function gTranslate(x, y, z) {
    modelMatrix = mult(modelMatrix, translate([x, y, z]));
}

// Post multiples the modelview matrix with a rotation matrix
// and replaces the modeling matrix with the result
function gRotate(theta, x, y, z) {
    modelMatrix = mult(modelMatrix, rotate(theta, [x, y, z]));
}

// Post multiples the modeling  matrix with a scaling matrix
// and replaces the modeling matrix with the result
function gScale(sx, sy, sz) {
    modelMatrix = mult(modelMatrix, scale(sx, sy, sz));
}

// Pops MS and stores the result as the current modelMatrix
function gPop() {
    modelMatrix = MS.pop();
}

// pushes the current modeling Matrix in the stack MS
function gPush() {
    MS.push(modelMatrix);
}

// puts the given matrix at the top of the stack MS
function gPut(m) {
    MS.push(m);
}

function render() {

    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    eye = vec3(0, 0, 20);
    MS = []; // Initialize modeling matrix stack

    // initialize the modeling matrix to identity
    modelMatrix = mat4();

    // set the camera matrix
    viewMatrix = lookAt(eye, at, up);

    // set the projection matrix
    projectionMatrix = ortho(left, right, bottom, ytop, near, far);
    //projectionMatrix = perspective(45, 1, near, far);

    // Rotations from the sliders
    gRotate(RZ, 0, 0, 1);
    gRotate(RY, 0, 1, 0);
    gRotate(RX, 1, 0, 0);


    // set all the matrices
    setAllMatrices();

    var curTime;
    if (animFlag) {
        curTime = (new Date()).getTime() / 1000;
        if (resetTimerFlag) {
            prevTime = curTime;
            resetTimerFlag = false;
        }
        TIME = TIME + curTime - prevTime;
        prevTime = curTime;
    }
    //Creating the Ground Box
    gPush(); // Push the current transformation matrix onto the stack
    {
        gTranslate(0, -6, 0); 
        gScale(200, 2, 2); 
        setColor(vec4(0.0, 0.0, 0.0, 1.0)); // Set the color of the cube to black
        drawCube(); // Drawing the Ground Box
    }
    gPop(); // Pop the transformation matrix from the stack

    //Creating the larger sphere
    gPush();
    {
        gTranslate(0, -3.5, 0);
        gScale(0.5, 0.5, 1);
        setColor(vec4(0.3, 0.3, 0.3, 1.0)); // Set the color of the sphere to gray
        drawSphere(); // Drawing the Ground Box
    }
    gPop();

    //Creating the smaller sphere
    gPush();
    {
        gTranslate(-0.8, -3.7, 0);
        gScale(0.3, 0.3, 1);
        setColor(vec4(0.3, 0.3, 0.3, 1.0)); // Set the color of the sphere to gray
        drawSphere(); // Drawing the Ground Box

    }
    gPop();

    //Seaweed
    var seaweed1 = [0.4, -3.7, 0];
    var seaweed2 = [0, -4, 0];
    var seaweed3 = [-0.4, -3.7, 0];

    //Seaweed #1
    gPush();
    {
        gTranslate(seaweed1[0], seaweed1[1], seaweed1[2]);
        // Draws 10 eclipses representing the seaweed

        for (var count = 0; count < 10; count++) {
            gTranslate(0, 0.50, 0);
            // Animation
            gRotate(0.5 * Math.cos(TIME + count) * 90 / Math.PI, 0, 0, 1);
            gPush();
            {
                gScale(0.1, 0.3, 0.5);
                setColor(vec4(0.0, 0.8, 0.0, 1.0)); // Sets the color of the plant to green
                drawSphere();
            }
            gPop();
        }
    }
    gPop();

    //Seaweed #2
    gPush();
    {
        gTranslate(seaweed2[0], seaweed2[1], seaweed2[2]);
        // Draws 10 eclipses representing the seaweed

        for (var count = 0; count < 10; count++) {
            gTranslate(0, 0.50, 0);
            // Animation
            gRotate(0.5 * Math.cos(TIME + count) * 90 / Math.PI, 0, 0, 1);
            gPush();
            {
                gScale(0.1, 0.3, 0.5);
                setColor(vec4(0.0, 0.8, 0.0, 1.0)); // Sets the color of the plant to green
                drawSphere();
            }
            gPop();
        }
    }
    gPop();

    //Seaweed #3
    gPush();
    {
        gTranslate(seaweed3[0], seaweed3[1], seaweed3[2]);
        // Draws 10 eclipses representing the seaweed

        for (var count = 0; count < 10; count++) {
            gTranslate(0, 0.50, 0);
            // Animation
            gRotate(0.5 * Math.cos(TIME + count) * 90 / Math.PI, 0, 0, 1);
            gPush();
            {
                gScale(0.1, 0.3, 0.5);
                setColor(vec4(0.0, 0.8, 0.0, 1.0)); // Sets the color of the plant to green
                drawSphere();
            }
            gPop();
        }
    }
    gPop();

    //Fish
    gPush();
    {
        //Animation making it rotate around the seaweed
        gRotate(TIME * 100 / Math.PI, 0, -1, 0); //Makes it rotate around the point
        gScale(-1, 1, 1);
        gTranslate(0, -7 + 0.05 * Math.cos(TIME / 0.8) * 45 / Math.PI, 0); //Makes it travel back and forth

        gPush();
        {
            gTranslate(3, 5, 0);
            //Body
            gPush();
            {
                gScale(0.5, 0.5, 2);
                setColor(vec4(0.4, 0.0, 0.0, 1.0));
                drawCone();
            }
            gPop();

            //Head
            gPush();
            {
                gTranslate(0, 0, -1.6);
                gScale(0.5, 0.5, -1.2);
                setColor(vec4(0.6, 0.6, 0.6, 1.0));
                drawCone();
            }
            gPop();

            //Total Tails
            gPush();
            {
                gRotate(Math.cos(TIME / 0.05) * 90 / Math.PI, 0, 1, 0); //Causes the tail to oscilate

                //Top portion of the Tail
                gPush();
                {
                    gTranslate(0, 0.4, 1);
                    gRotate(-80, 4, 0, 0);
                    gScale(0.25, 0.25, 0.8);
                    setColor(vec4(0.4, 0.0, 0.0, 1.0));
                    drawCone();
                }
                gPop();

                //Bottom portion of the Tail
                gPush();
                {
                    gTranslate(0, -0.4, 1);
                    gRotate(80, 4, 0, 0);
                    gScale(0.25, 0.25, 0.8);
                    setColor(vec4(0.4, 0.0, 0.0, 1.0));
                    drawCone();
                }
                gPop();

            }
            gPop();

            //Fish Right Eye
            gPush();
            {
                gTranslate(0.38, 0.25, -1.45);
                gScale(0.15, 0.15, 0.15);
                setColor(vec4(1.0, 1.0, 1.0, 1.0));
                drawSphere();
            }
            gPop();

            //Fish Right Eye Pupil
            gPush();
            {
                gTranslate(0.38, 0.25, -1.65);
                gScale(0.05, 0.05, 0.05);
                setColor(vec4(0, 0, 0, 0));
                drawSphere();
            }
            gPop();

            //Fish Left Eye
            gPush();
            {
                gTranslate(-0.38, 0.25, -1.45);
                gScale(0.15, 0.15, 0.15);
                setColor(vec4(1.0, 1.0, 1.0, 1.0));
                drawSphere();
            }
            gPop();
            //Fish Left Eye Pupil
            gPush();
            {
                gTranslate(-0.38, 0.25, -1.65);
                gScale(0.05, 0.05, 0.05);
                setColor(vec4(0, 0, 0, 0));
                drawSphere();
            }
            gPop();

        }
        gPop();
    }
    gPop();

    //Diver
    var diver = 3 + Math.cos(TIME/2);

    gPush();
    {
        gTranslate(diver, diver, 0);
        gRotate(30, 0, -1, 0);

        //Diver's Head
        gPush(); {

            gScale(0.4, 0.4, 0.4);
            setColor(vec4(0.8, 0.0, 0.8, 1.0));
            drawSphere();

            if ((Math.round(TIME) - lastLaunch) % 4) {
                drawBubble(0, 0.5, 0, 0); //Supposed to launch a bubble every 4 seconds, instead launches a bubble only the first second and does not repeat
                lastLaunch = TIME;

            }

        }
        gPop();

        //Torso
        gPush(); {
            gTranslate(0, -1.55, 0);
            gScale(0.8, 1.2, 0.5);
            setColor(vec4(0.8, 0.0, 0.8, 1.0));
            drawCube()
        }
        gPop();

        gPush();
        {
            //Legs
            gTranslate(0, -3, 0);
            setColor(vec4(0.8, 0.0, 0.8, 1.0));

            //Leg 1
            gPush(); {
                gTranslate(-0.6, 0, -0.2);
                gRotate(-(Math.cos(TIME) * 25) + 30, 1, 0, 0); //Rotates the whole leg joint

                // Thigh
                gPush();
                {
                    gScale(0.15, 0.7, 0.15);
                    drawCube();
                }
                gPop();

                //  Shin
                gTranslate(0, -1.4, -0.3);
                gRotate(25, 1, 0, 0);

                gPush();
                {
                    gScale(0.15, 0.7, 0.15);
                    drawCube();
                }
                gPop();
                // Foot does not rotate
                gTranslate(0, -0.6, 0.5);

                gPush();
                {
                    gScale(0.15, 0.1, 0.6);
                    drawCube();
                }
                gPop();
            }
            gPop();

            //Leg 2 
            gPush();
            {
                gTranslate(0.6, 0, -0.15);
                gRotate((Math.cos(TIME) * 25) + 30, 1, 0, 0);
                // Thigh
                gPush();
                {
                    gScale(0.15, 0.5, 0.15);
                    drawCube();
                }
                gPop();

                // Shin
                gTranslate(0, -1.4, -0.3);
                gRotate(25, 1, 0, 0);

                gPush();
                {
                    gScale(0.15, 0.7, 0.15);
                    drawCube();
                }
                gPop();

                // Foot
                gTranslate(0, -0.6, 0.5);

                gPush();
                {
                    gScale(0.15, 0.1, 0.6);
                    drawCube();
                }
                gPop();
            }
            gPop();
        }
        gPop();

    }
    gPop();


    /**
     * Draws a bubble at the specified coordinates, with an animation that starts at the given start time.
     *
     * @param {number} x - The x-coordinate of the bubble.
     * @param {number} y - The y-coordinate of the bubble.
     * @param {number} z - The z-coordinate of the bubble.
     * @param {number} startTime - The start time of the animation.
     */
    function drawBubble(x, y, z, startTime) {
        var numBubbles = 4; // Number of bubbles to launch
        var speed = 1.5; // Adjust the speed as needed

        for (var i = 0; i < numBubbles; i++) {
            var elapsedTime = TIME - startTime - i * 0.5; // Adjust the delay between bubbles

            if (elapsedTime > 0) {
                gPush();
                {
                    // Calculate the new y position based on elapsed time and speed
                    var newYPos = y + elapsedTime * speed;

                    gTranslate(x, newYPos, z);
                    gRotate(2* (TIME % 360) * 100, 5, 5, 5); // This makes the bubbles oscillate
                    gScale(0.3, 0.35, 0.3);
                    setColor(vec4(1, 1, 1, 1));
                    drawSphere();
                }
                gPop();
            }
        }
    }


    if (animFlag)
        window.requestAnimFrame(render);
}

// A simple camera controller which uses an HTML element as the event
// source for constructing a view matrix. Assign an "onchange"
// function to the controller as follows to receive the updated X and
// Y angles for the camera:
//
//   var controller = new CameraController(canvas);
//   controller.onchange = function(xRot, yRot) { ... };
//
// The view matrix is computed elsewhere.
function CameraController(element) {
    var controller = this;
    this.onchange = null;
    this.xRot = 0;
    this.yRot = 0;
    this.scaleFactor = 3.0;
    this.dragging = false;
    this.curX = 0;
    this.curY = 0;

    // Assign a mouse down handler to the HTML element.
    element.onmousedown = function (ev) {
        controller.dragging = true;
        controller.curX = ev.clientX;
        controller.curY = ev.clientY;
    };

    // Assign a mouse up handler to the HTML element.
    element.onmouseup = function (ev) {
        controller.dragging = false;
    };

    // Assign a mouse move handler to the HTML element.
    element.onmousemove = function (ev) {
        if (controller.dragging) {
            // Determine how far we have moved since the last mouse move
            // event.
            var curX = ev.clientX;
            var curY = ev.clientY;
            var deltaX = (controller.curX - curX) / controller.scaleFactor;
            var deltaY = (controller.curY - curY) / controller.scaleFactor;
            controller.curX = curX;
            controller.curY = curY;
            // Update the X and Y rotation angles based on the mouse motion.
            controller.yRot = (controller.yRot + deltaX) % 360;
            controller.xRot = (controller.xRot + deltaY);
            // Clamp the X rotation to prevent the camera from going upside
            // down.
            if (controller.xRot < -90) {
                controller.xRot = -90;
            } else if (controller.xRot > 90) {
                controller.xRot = 90;
            }
            // Send the onchange event to any listener.
            if (controller.onchange != null) {
                controller.onchange(controller.xRot, controller.yRot);
            }
        }
    };
}
